package com.mindgate.main;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class FilterMain {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("Sivaprasad", "Santhosh", "Sai Eswari", "Jothi", "Poornima");

		System.out.println("All Names");
		// names.forEach(p -> System.out.println(p));
		names.forEach(System.out::println);

		System.out.println("");
		System.out.println("Print All Accept Sai Eswari");

		names.forEach(p -> {
			if (!p.equals("Sai Eswari"))
				System.out.println(p);
		});

		System.out.println("Using Streams");
		names.stream().filter(new Predicate<String>() {

			@Override
			public boolean test(String name) {
				return !name.equals("Sai Eswari");
			}
		}).forEach(new Consumer<String>() {

			@Override
			public void accept(String name) {
				System.out.println(name);
			}

		});

		System.out.println("");
		names.stream().filter(name -> !name.equals("Sai Eswari")).forEach(s -> System.out.println(s));
		names.stream().filter(name -> !name.equals("Sai Eswari")).forEach(System.out::println);
		

	}
}

