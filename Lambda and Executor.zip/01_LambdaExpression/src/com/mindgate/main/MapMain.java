package com.mindgate.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.mindgate.main.domain.Person;

public class MapMain {
	public static void main(String[] args) {
		List<String> alphabets = Arrays.asList("a", "b", "c", "d", "e");

		// Convert this alphabets into upper case and add it into new list
		List<String> alphabetsUpper = new ArrayList<String>();

		for (String s : alphabets) {
			alphabetsUpper.add(s.toUpperCase());
		}

		System.out.println(alphabetsUpper);

		System.out.println("Using Java 8");
		// Java 8 Streams
		alphabets.stream().map(new Function<String, String>() {

			@Override
			public String apply(String s) {
				return s.toUpperCase();
			}
		}).forEach(new Consumer<String>() {

			@Override
			public void accept(String t) {
				System.out.println(t);
			}

		});
		System.out.println("");
		// alphabets.stream().map(s -> s.toUpperCase()).forEach(s ->
		// System.out.println(s));
		alphabets.stream().map(s -> s.toUpperCase()).forEach(System.out::println);
		alphabetsUpper = alphabets.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
		alphabetsUpper.forEach(System.out::println);

		List<Person> persons = Arrays.asList(new Person("Gokul", "S", 23), new Person("Hari", "T", 22),
				new Person("Anand", "K", 22), new Person("Poorna Chanda", "P", 22), new Person("Rishabh", "Tiwari", 23),
				new Person("Shiva Prasad", "G", 23));

		// Print all the first name in upper case from the persons using map method and
		// collect into list
		// Print all firstnames

		List<String> names = persons.stream().map(p -> p.getFirstName().toUpperCase()).collect(Collectors.toList());
		names.forEach(System.out::println);
		

		List<Person> allPersons = persons.stream().map(new Function<Person, Person>() {

			@Override
			public Person apply(Person p) {
				p.setFirstName(p.getFirstName().toUpperCase());
				return p;
			}

		}).collect(Collectors.toList());
		allPersons.forEach(System.out::println);

		allPersons = persons.stream().map(p -> {
			p.setFirstName(p.getFirstName().toUpperCase());
			return p;
		}).collect(Collectors.toList());
		allPersons.forEach(System.out::println);
	}
}
