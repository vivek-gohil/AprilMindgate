package com.mindgate.main;

import java.util.Arrays;
import java.util.function.IntBinaryOperator;

public class ReduceMain {
	public static void main(String[] args) {
		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		int sum = 0;

		// Print sum of all numbers from array
		for (int i : numbers) {
			sum += i;
		}

		System.out.println(sum);

//		sum = Arrays.stream(numbers).reduce(0, new IntBinaryOperator() {
//
//			@Override
//			public int applyAsInt(int left, int right) {
//				System.out.println("Value of left = " + left + " right = " + right);
//				int result = left + right;
//				return result;
//			}
//		});
		sum = Arrays.stream(numbers).reduce(0, (l, r) -> l + r);
		System.out.println(sum);

	}
}
