package com.mindgate.main.thread;

import com.mindgate.main.domain.Message;

public class MessageThreaad implements Runnable {
	@Override
	public void run() {
		Message.print();
	}
}
