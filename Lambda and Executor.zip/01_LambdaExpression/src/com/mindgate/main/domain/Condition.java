package com.mindgate.main.domain;

public interface Condition {
	public boolean test(Person p);
}
