package com.mindgate.main.domain;

public class Message {
	public static void print() {
		System.out.println("Message class print()");
	}
}
