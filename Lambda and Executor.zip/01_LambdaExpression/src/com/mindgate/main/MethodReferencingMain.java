package com.mindgate.main;

import com.mindgate.main.domain.Message;
import com.mindgate.main.thread.MessageThreaad;

public class MethodReferencingMain {
	public static void main(String[] args) {
		greet();
		
		System.out.println();
		
		Message.print();
		
		System.out.println();
		
		MessageThreaad messageThreaad = new MessageThreaad();
		Thread thread = new Thread(messageThreaad);
		thread.start();
		
		System.out.println();
		
		//Lambda Expression
		Runnable runnable = () -> Message.print();
		Thread thread2 = new Thread(runnable);
		thread2.start();
		
		//Lambda Expression
		System.out.println();
		new Thread(() -> Message.print()).start();

		//Method Reference
		new Thread(Message:: print).start();
		
		
	}

	public static void greet() {
		System.out.println("Hello From Greet()");
	}
}
