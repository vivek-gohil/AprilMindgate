package com.mindgate.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SoretedMain {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("9", "A", "Z", "1", "B", "Y", "a", "c");

//		Collections.sort(list);
//
//		System.out.println(list);

		List<String> sortedList = list.stream().sorted().collect(Collectors.toList());
		sortedList.forEach(System.out::println);

		System.out.println("Sort in reverse order");

		sortedList = list.stream().sorted(new Comparator<String>() {

			@Override
			public int compare(String s1, String s2) {
				return s2.compareTo(s1);
			}
		}).collect(Collectors.toList());
		
		
		System.out.println(list);
		System.out.println(sortedList);
	}
}
