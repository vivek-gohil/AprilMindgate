package com.mindgate.main;

public class ThreadsMain {
	public static void main(String[] args) {
//		Runnable runnable = new Runnable() {
//			@Override
//			public void run() {
//				System.out.println("Thread start");
//				for (int i = 0; i < 10; i++) {
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//					System.out.println("i = " + i);
//				}
//
//			}
//		};

		Runnable runnable = () -> {
			System.out.println("Thread is running");
		};

		Thread thread = new Thread(runnable);
		thread.start();
	}
}

















