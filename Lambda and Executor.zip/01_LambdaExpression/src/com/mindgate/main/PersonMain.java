package com.mindgate.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.mindgate.main.domain.Person;

//No lambda Expressions
public class PersonMain {
	public static void printAllPersonsFirstNameEndsWithD(List<Person> persons) {
		for (Person person : persons) {
			if (person.getFirstName().endsWith("d"))
				System.out.println(person);
		}
	}

	public static void printAllPersonsLastNameStartsWithT(List<Person> persons) {
		for (Person person : persons) {
			if (person.getLastName().startsWith("T"))
				System.out.println(person);
		}
	}

	public static void printAllPersons(List<Person> persons) {
		for (Person person : persons) {
			System.out.println(person);
		}
	}

	public static void main(String[] args) {

		List<Person> persons = Arrays.asList(new Person("Gokul", "S", 23), new Person("Hari", "T", 22),
				new Person("Anand", "K", 22), new Person("Poorna Chanda", "P", 22), new Person("Rishabh", "Tiwari", 23),
				new Person("Shiva Prasad", "G", 23));

		System.out.println("1. Sort all persons object by its FirstName");
		Comparator<Person> sortPersonByFirstName = new Comparator<Person>() {
			@Override
			public int compare(Person p1, Person p2) {
				return p1.getFirstName().compareTo(p2.getFirstName());
			}
		};
		Collections.sort(persons, sortPersonByFirstName);

		System.out.println();
		System.out.println("2. Create a function to print all persons and call it from main");
		printAllPersons(persons);

		System.out.println();
		System.out.println("3. Create a function to print persons whos last name starts with T");
		printAllPersonsLastNameStartsWithT(persons);

		System.out.println();
		System.out.println("4. Create a function to print persons whos first name ends with d");
		printAllPersonsFirstNameEndsWithD(persons);

	}

}
