package com.mindgate.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindgate.main.configuration.ApplicationConfiguration;
import com.mindgate.main.domain.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		System.out.println("Main start");

		System.out.println("Main is creating ApplicationContext object");
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		System.out.println("ApplicationContext object is created");

		Employee employee = applicationContext.getBean(Employee.class);
		System.out.println(employee.hashCode());
		System.out.println(employee);

		System.out.println("--------------------------------");
		Employee employee2 = applicationContext.getBean(Employee.class);
		System.out.println(employee2.hashCode());
		System.out.println(employee2);

		System.out.println("Main end");
	}
}
