package com.mindgate.main.domain;

public class Address {
	private int addressId;
	private String doorNumber;
	private String street;
	private String city;
	private String state;
	private int pin;

	public Address() {
		System.out.println("Default constructor of Address");
	}

	public Address(int addressId, String doorNumber, String street, String city, String state, int pin) {
		super();
		this.addressId = addressId;
		this.doorNumber = doorNumber;
		this.street = street;
		this.city = city;
		this.state = state;
		this.pin = pin;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", doorNumber=" + doorNumber + ", street=" + street + ", city="
				+ city + ", state=" + state + ", pin=" + pin + "]";
	}

}
