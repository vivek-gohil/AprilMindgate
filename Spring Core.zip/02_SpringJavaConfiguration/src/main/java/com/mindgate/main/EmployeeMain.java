package com.mindgate.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindgate.main.configuration.ApplicationConfiguration;
import com.mindgate.main.domain.Address;
import com.mindgate.main.domain.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		ApplicationContext applicationContext 
							= new AnnotationConfigApplicationContext(ApplicationConfiguration.class);

		Address address = applicationContext.getBean(Address.class);

		System.out.println(address);

		Employee employee = applicationContext.getBean(Employee.class);

		System.out.println(employee);
	}
}
