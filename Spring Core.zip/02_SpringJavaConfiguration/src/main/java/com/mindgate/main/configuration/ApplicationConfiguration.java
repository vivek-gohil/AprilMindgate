package com.mindgate.main.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mindgate.main.domain.Address;
import com.mindgate.main.domain.Employee;

@Configuration
public class ApplicationConfiguration {

	@Bean
	public Address getAddress() {
		return new Address();
	}

	@Bean
	public Employee getEmployee() {
		return new Employee();
	}
}
