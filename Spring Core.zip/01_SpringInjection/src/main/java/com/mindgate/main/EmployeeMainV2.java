package com.mindgate.main;

public class EmployeeMainV2 {
	public static void main(String[] args) {
		//1. Inject EmployeeService Object , it should inject EmployeeRepository also
		//2. call print method using EmployeeService object
	}
}
