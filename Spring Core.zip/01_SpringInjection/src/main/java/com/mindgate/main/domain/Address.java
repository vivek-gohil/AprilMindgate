package com.mindgate.main.domain;

public class Address {
	private int addressId;
	private String doorNumber;
	private String street;
	private String city;
	private String state;
	private int pinCode;

	public Address() {
		System.out.println("default constructor of Address");
	}

	public Address(int addressId, String doorNumber, String street, String city, String state, int pinCode) {
		System.out.println("Overloaded constructor of Address");
		this.addressId = addressId;
		this.doorNumber = doorNumber;
		this.street = street;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		System.out.println("setAddressId=" + addressId);
		this.addressId = addressId;
	}

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", doorNumber=" + doorNumber + ", street=" + street + ", city="
				+ city + ", state=" + state + ", pinCode=" + pinCode + "]";
	}

}
