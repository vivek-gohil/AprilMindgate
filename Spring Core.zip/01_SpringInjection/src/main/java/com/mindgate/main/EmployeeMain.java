package com.mindgate.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mindgate.main.domain.Address;
import com.mindgate.main.domain.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");

		Address address = applicationContext.getBean("homeAddress", Address.class);

		System.out.println(address);

		Employee employee = applicationContext.getBean("employee", Employee.class);

		System.out.println(employee);
	}
}








