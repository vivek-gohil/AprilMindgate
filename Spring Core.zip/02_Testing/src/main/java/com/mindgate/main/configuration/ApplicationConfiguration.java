package com.mindgate.main.configuration;

@Configuration
public class ApplicationConfiguration {

}
