package com.mindgate.main.configuration;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.mindgate.main.domain.Employee;
import com.mindgate.main.repository.EmployeeRepository;

@Configuration
public class ApplicationConfiguration {

	@Bean
	public Employee getEmployee() {
		return new Employee();
	}

	@Bean
	public DataSource getDataSource() {
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		driverManagerDataSource.setUsername("training");
		driverManagerDataSource.setPassword("training");
		driverManagerDataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");

		return driverManagerDataSource;
	}

	@Bean
	public JdbcTemplate getJdbcTemplate() {
		return new JdbcTemplate(getDataSource());
	}

	@Bean
	public EmployeeRepository getEmployeeRepository() {
		return new EmployeeRepository();
	}

}
