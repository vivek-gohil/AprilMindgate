package com.mindgate.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindgate.main.configuration.ApplicationConfiguration;
import com.mindgate.main.domain.Employee;
import com.mindgate.main.repository.EmployeeRepository;

public class EmployeeMain {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);

		Employee employee = applicationContext.getBean(Employee.class);

		EmployeeRepository employeeRepository = applicationContext.getBean(EmployeeRepository.class);

		System.out.println(employee);
	}
}
