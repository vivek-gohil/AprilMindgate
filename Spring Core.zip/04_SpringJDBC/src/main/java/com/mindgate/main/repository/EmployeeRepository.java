package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mindgate.main.domain.EmployeeDetails;

@Component
public class EmployeeRepository implements EmployeeDetailsRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_NEW_EMPLOYEE = "INSERT INTO employee_details(name,salary) VALUES(?,?)";
	private static final String SELECT_ONE_EMPLOYEE = "SELECT * FROM employee_details WHERE employee_id=?";
	private static final String SELECT_ALL_EMPLOYEES = "SELECT * FROM employee_details";
	private static final String UPDATE_EMPLOYEE = "UPDATE employee_details SET name=?,salary=? WHERE employee_id=?";
	private static final String DELETE_EMPLOYEE = "DELETE FROM employee_details WHERE employee_id=?";

	@Override
	public boolean addNewEmployee(EmployeeDetails employeeDetails) {
		Object[] parameters = { employeeDetails.getName(), employeeDetails.getSalary() };
		int resultCount = jdbcTemplate.update(INSERT_NEW_EMPLOYEE, parameters);
		if (resultCount > 0)
			return true;
		return false;
	}

	@Override
	public EmployeeDetails getOneEmployeeDetails(int employeeId) {
		EmployeeDetailsRowMapper employeeDetailsRowMapper = new EmployeeDetailsRowMapper();
		EmployeeDetails employeeDetails = jdbcTemplate.queryForObject(SELECT_ONE_EMPLOYEE, employeeDetailsRowMapper,
				employeeId);
		return employeeDetails;
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() {
		EmployeeDetailsRowMapper employeeDetailsRowMapper = new EmployeeDetailsRowMapper();
		List<EmployeeDetails> allEmployees = jdbcTemplate.query(SELECT_ALL_EMPLOYEES, employeeDetailsRowMapper);
		return allEmployees;
	}

	@Override
	public EmployeeDetails updateEmployeeDetails(EmployeeDetails employeeDetails) {
		Object[] parameters = { employeeDetails.getName(), employeeDetails.getSalary(),
				employeeDetails.getEmployeeId() };

		int resultCount = jdbcTemplate.update(UPDATE_EMPLOYEE, parameters);
		if (resultCount > 0)
			return employeeDetails;
		return null;
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		int resultCount = jdbcTemplate.update(DELETE_EMPLOYEE, employeeId);
		if (resultCount > 0)
			return true;
		return false;
	}

}




