package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;

public interface EmployeeDetailsRepositoryInterface {
	public boolean addNewEmployee(EmployeeDetails employeeDetails);

	public EmployeeDetails getOneEmployeeDetails(int employeeId);

	public List<EmployeeDetails> getAllEmployeeDetails();

	public EmployeeDetails updateEmployeeDetails(EmployeeDetails employeeDetails);

	public boolean deleteEmployeeByEmployeeId(int employeeId);
}
