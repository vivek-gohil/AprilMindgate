package com.mindgate.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindgate.main.configuration.ApplicationConfiguration;
import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.service.EmployeeDetailsService;
import com.mindgate.main.service.EmployeeDetailsServiceInterface;

public class EmployeeCRUDMain {
	public static void main(String[] args) {

		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);

		EmployeeDetailsServiceInterface employeeDetailsServiceInterface = applicationContext
				.getBean(EmployeeDetailsService.class);
		System.out.println("Updating employee details");
		EmployeeDetails employeeDetails = new EmployeeDetails(2, "Hari", 5000);

		EmployeeDetails updatedEmployeeDetails = employeeDetailsServiceInterface.updateEmployeeDetails(employeeDetails);
		if (updatedEmployeeDetails != null)
			System.out.println(updatedEmployeeDetails);
		else
			System.out.println("Failed to update");

		System.out.println("Delete employee id = 11");
		int employeeId = 11;
		boolean result = employeeDetailsServiceInterface.deleteEmployeeByEmployeeId(employeeId);
		if (result)
			System.out.println("Employee deleted successfully");
		else
			System.out.println("Failed to delete employee");

//		System.out.println("Select all employee details");
//		List<EmployeeDetails> allEmployees = employeeDetailsServiceInterface.getAllEmployeeDetails();
//		for (EmployeeDetails employeeDetails : allEmployees) {
//			System.out.println(employeeDetails);
//		}
//
//		System.out.println("");
//		System.out.println("Select one employee");
//		int employeeId = 11;
//		EmployeeDetails employeeDetails = employeeDetailsServiceInterface.getOneEmployeeDetails(employeeId);
//		System.out.println(employeeDetails);

//		EmployeeDetails employeeDetails = new EmployeeDetails(0, "Seema", 1000);
//
//		boolean result = employeeDetailsServiceInterface.addNewEmployee(employeeDetails);
//
//		if (result)
//			System.out.println("Employee record inserted successfully!");
//		else
//			System.out.println("Failed to add new employee!");

	}
}
