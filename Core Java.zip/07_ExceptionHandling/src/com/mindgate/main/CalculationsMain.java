package com.mindgate.main;

import com.mindgate.main.domain.Calculations;

public class CalculationsMain {

	public static void main(String[] args) {
		System.out.println("main start");

		Calculations calculations = new Calculations();
		calculations.accept();
		calculations.calculate();
		calculations.display();

		System.out.println("main ends");
	}

}
