package com.mindgate.main.exception;

public class InvalidSalaryException extends Exception {
	public InvalidSalaryException() {
		System.out.println("InvalidSalaryException Object Created");
	}

	@Override
	public String getMessage() {
		return "Invalid Salary , Salary > 0";
	}

}
