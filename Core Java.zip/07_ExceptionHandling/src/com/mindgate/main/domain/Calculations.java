package com.mindgate.main.domain;

import java.util.Scanner;

public class Calculations {

	private double number1, number2, result;
	public void accept() {
		try {

			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter first number");
			number1 = scanner.nextDouble();
			System.out.println("Enter second number");
			number2 = scanner.nextDouble();
		} catch (Exception e) {
			// code
			System.out.println("Oops... Invalid Number !!");
			System.out.println("System Message = " + e.getMessage());
		}
	}

	public void calculate() {
		System.out.println("Calculating result");
		result = number1 + number2;
	}

	public void display() {
		System.out.println("Result = " + result);

	}

}
