package com.mindgate.main;

import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.service.EmployeeDetailsService;
import com.mindgate.main.service.EmployeeDetailsServiceInterface;

public class EmployeeDetailsCRUDMain {

	public static void main(String[] args) {
		EmployeeDetailsServiceInterface employeeDetailsServiceInterface = new EmployeeDetailsService();

		int employeeId = 1;

		EmployeeDetails employeeDetails = employeeDetailsServiceInterface.getEmployeeByEmployeeId(employeeId);

		System.out.println(employeeDetails);

//		List<EmployeeDetails> allEmployeeDetails = employeeDetailsServiceInterface.getAllEmployeeDetails();
//
//		for (EmployeeDetails employeeDetails : allEmployeeDetails) {
//			System.out.println(employeeDetails);
//		}

//		EmployeeDetails employeeDetails = new EmployeeDetails(0, "Mindgate", 1000);
//
//		boolean result = employeeDetailsServiceInterface.addNewEmployee(employeeDetails);
//
//		if (result) {
//			System.out.println("Employee inserted successfully");
//		} else {
//			System.out.println("Failed to insert employee");
//		}
	}

}
