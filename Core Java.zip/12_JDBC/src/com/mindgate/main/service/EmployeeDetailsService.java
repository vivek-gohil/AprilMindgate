package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.repository.EmployeeDetailsRepository;
import com.mindgate.main.repository.EmployeeDetailsRepositoryInterface;

public class EmployeeDetailsService implements EmployeeDetailsServiceInterface {

	private EmployeeDetailsRepositoryInterface employeeDetailsRepositoryInterface = new EmployeeDetailsRepository();

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		return employeeDetailsRepositoryInterface.deleteEmployeeByEmployeeId(employeeId);
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() {

		return employeeDetailsRepositoryInterface.getAllEmployeeDetails();
	}

	@Override
	public boolean addNewEmployee(EmployeeDetails employeeDetails) {
		System.out.println("in addNewEmployee() of Service");
		return employeeDetailsRepositoryInterface.addNewEmployee(employeeDetails);
	}

	@Override
	public EmployeeDetails getEmployeeByEmployeeId(int employeeId) {

		return employeeDetailsRepositoryInterface.getEmployeeByEmployeeId(employeeId);
	}

}
