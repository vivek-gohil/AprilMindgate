package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;

public interface EmployeeDetailsServiceInterface {
	public boolean addNewEmployee(EmployeeDetails employeeDetails);

	public List<EmployeeDetails> getAllEmployeeDetails();

	public EmployeeDetails getEmployeeByEmployeeId(int employeeId);

	public boolean deleteEmployeeByEmployeeId(int employeeId);
}
