package com.mindgate.main.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;

public class EmployeeDetailsRepository implements EmployeeDetailsRepositoryInterface {

	private String user = "training";
	private String password = "training";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;

	private static final String INSERT_EMPLOYEE_DETAILS = "INSERT INTO employee_details(name,salary) VALUES(?,?)";
	private static final String SELECT_ALL_EMPLOYEE = "SELECT * FROM employee_details";
	private static final String SELECT_ONE_EMPLOYEE = "SELECT * FROM employee_details WHERE employee_id=?";
	private static final String DELETE_ONE_EMPLOYEE = "DELETE FROM employee_details WHERE employee_id=?";

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			preparedStatement = connection.prepareStatement(DELETE_ONE_EMPLOYEE);
			preparedStatement.setInt(1, employeeId);

			int resultCount = preparedStatement.executeUpdate();
			if (resultCount > 0)
				return true;
		} catch (SQLException e) {
			System.out.println("Failed to connect database server");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			e.printStackTrace();
		} finally {
			System.out.println("in finally block");
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				System.out.println("Failed to close PreparedStatement/Connection");
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			preparedStatement = connection.prepareStatement(SELECT_ALL_EMPLOYEE);
			resultSet = preparedStatement.executeQuery();

			List<EmployeeDetails> allEmployeeDetails = new ArrayList<EmployeeDetails>();

			while (resultSet.next()) {
				int employeeId = resultSet.getInt("employee_id");
				String name = resultSet.getString("name");
				double salary = resultSet.getDouble("salary");

				EmployeeDetails employeeDetails = new EmployeeDetails(employeeId, name, salary);
				allEmployeeDetails.add(employeeDetails);
			}

			return allEmployeeDetails;

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Failed to connect database server");
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean addNewEmployee(EmployeeDetails employeeDetails) {
		System.out.println("in addNewEmployee() of Repositry");
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			preparedStatement = connection.prepareStatement(INSERT_EMPLOYEE_DETAILS);
			preparedStatement.setString(1, employeeDetails.getName());
			preparedStatement.setDouble(2, employeeDetails.getSalary());

			int resultCount = preparedStatement.executeUpdate();
			if (resultCount > 0)
				return true;

		} catch (SQLException e) {
			System.out.println("Failed to connect database server");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			e.printStackTrace();
		} finally {
			System.out.println("in finally block");
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				System.out.println("Failed to close PreparedStatement/Connection");
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public EmployeeDetails getEmployeeByEmployeeId(int employeeId) {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			preparedStatement = connection.prepareStatement(SELECT_ONE_EMPLOYEE);
			preparedStatement.setInt(1, employeeId);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employeeId = resultSet.getInt("employee_id");
				String name = resultSet.getString("name");
				double salary = resultSet.getDouble("salary");

				EmployeeDetails employeeDetails = new EmployeeDetails(employeeId, name, salary);
				return employeeDetails;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Failed to connect database server");
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public EmployeeDetails updateEmployeeDetails(EmployeeDetails employeeDetails) {
		// TODO Auto-generated method stub
		return null;
	}

}
