package com.mindgate.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionTestMain {

	public static void main(String[] args) {
		String userName = "training";
		String password = "training";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String driverClassName = "oracle.jdbc.driver.OracleDriver";
		Connection connection = null;
		// 1. Load the driver in JVM
		try {
			Class.forName(driverClassName);
			connection = DriverManager.getConnection(url, userName, password);
			if (connection != null) {
				System.out.println("Connection successfull!");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver class");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Failed to connect database server");
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Failed to close connection");
			}
		}

	}

}
