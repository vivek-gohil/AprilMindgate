package com.mindgate.main;

import com.mindgate.main.threads.ThreadOne;
import com.mindgate.main.threads.ThreadTwo;

public class ThreadMain {
	public static void main(String[] args) {
		System.out.println("main start");

		ThreadOne threadOne = new ThreadOne();
		threadOne.start();

		int i = 0;
		while (i < 1000) {
			System.out.println("main " + i);
			i++;
		}
		
		ThreadTwo threadTwo = new ThreadTwo();
		Thread thread = new Thread(threadTwo);
		thread.start();

		System.out.println("main end");
	}
}









