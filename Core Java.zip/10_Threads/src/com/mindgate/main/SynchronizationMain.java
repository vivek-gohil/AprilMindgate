package com.mindgate.main;

import com.mindgate.main.resource.CallMe;
import com.mindgate.main.threads.Caller;

public class SynchronizationMain {
	public static void main(String[] args) {
		CallMe callMe = new CallMe();

		Caller hari = new Caller(callMe, "Hi");
		Caller anand = new Caller(callMe, "Hello");
		Caller poorna = new Caller(callMe, "How are you");

		Thread thread1 = new Thread(hari);
		Thread thread2 = new Thread(anand);
		Thread thread3 = new Thread(poorna);

		thread1.start();
		thread2.start();
		thread3.start();
	}
}
