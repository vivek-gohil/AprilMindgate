package com.mindgate.main;

import com.mindgate.main.resource.Account;
import com.mindgate.main.threads.DepositThread;
import com.mindgate.main.threads.WithdrawThread;

public class TransactionMain {
	public static void main(String[] args) {

		Account account = new Account();

		WithdrawThread withdrawThread = new WithdrawThread(2000, account);
		Thread thread1 = new Thread(withdrawThread);
		thread1.start();

		DepositThread depositThread = new DepositThread(50000, account);
		Thread thread2 = new Thread(depositThread);
		thread2.start();
	}
}
