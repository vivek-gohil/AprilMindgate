package com.mindgate.main.threads;

public class ThreadOne extends Thread {
	@Override
	public void run() {
		System.out.println("We are in ThreadOne");
		int i = 0;
		while (i < 1000) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("ThreadOne " + i);
			i++;
		}
	}
}
