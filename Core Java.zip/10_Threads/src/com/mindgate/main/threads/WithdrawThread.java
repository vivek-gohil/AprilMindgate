package com.mindgate.main.threads;

import com.mindgate.main.resource.Account;

public class WithdrawThread implements Runnable {
	private double amount;
	private Account account;

	public WithdrawThread(double amount, Account account) {
		super();
		this.amount = amount;
		this.account = account;
	}

	@Override
	public void run() {
		account.withdraw(amount);
	}
}
