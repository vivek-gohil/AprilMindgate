package com.mindgate.main.threads;

import com.mindgate.main.resource.Account;

public class DepositThread implements Runnable {
	private double amount;
	private Account account;

	public DepositThread(double amount, Account account) {
		super();
		this.amount = amount;
		this.account = account;
	}

	@Override
	public void run() {
		account.deposit(amount);
	}
}
