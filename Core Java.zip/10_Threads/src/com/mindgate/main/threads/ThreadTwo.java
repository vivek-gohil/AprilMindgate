package com.mindgate.main.threads;

public class ThreadTwo implements Runnable {

	@Override
	public void run() {
		System.out.println("We are in Thread Two");
	}
}
