package com.mindgate.main.resource;

public class Account {
	private double balance = 1000;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public synchronized void withdraw(double amount) {
		System.out.println("Starting withdraw ");
		System.out.println("amount = " + amount);
		if (amount > balance) {
			try {
				System.out.println("Less balance : waiting for deposit");
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		balance = balance - amount;
		System.out.println("withdraw completed");
	}

	public synchronized void deposit(double amount) {
		System.out.println("Starting deposit");
		System.out.println("amount =  " + amount);
		balance = balance + amount;
		System.out.println("deposit completed");
		notify();
	}
}
