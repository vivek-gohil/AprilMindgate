package com.mindgate.main;

import com.mindgate.main.domain.A;
import com.mindgate.main.domain.B;

public class AbstractMain {

	public static void main(String[] args) {
		A a ;
		a = new B();
		a.display(); // class A display
		a.print(); //always child class print
	}

}
