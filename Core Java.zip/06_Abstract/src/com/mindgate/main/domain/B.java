package com.mindgate.main.domain;

public class B extends A {

	@Override
	public void print() {
		System.out.println("Mindgate");
	}

}
