package com.mindgate.main.domain;

public class C extends A{

	@Override
	public void print() {
		System.out.println("Java");
	}

}
