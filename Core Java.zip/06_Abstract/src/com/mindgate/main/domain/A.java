package com.mindgate.main.domain;

public abstract class A {
	public abstract void print();
	
	public void display() {
			System.out.println("Hello");
	}
}
