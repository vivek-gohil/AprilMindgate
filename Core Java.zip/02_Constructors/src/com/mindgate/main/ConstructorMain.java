package com.mindgate.main;

import com.mindgate.main.domain.B;

public class ConstructorMain {

	public static void main(String[] args) {

		System.out.println("main start");

		// B b = new B(); // Default constructor of A , Default constructor of B

		B b = new B(10, 20, 30);

		System.out.println("main end");

	}

}
