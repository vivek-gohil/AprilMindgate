package com.mindgate.main.domain;

public class B extends A {
	public B() {
		System.out.println("Default constructor of B");
	}

	public B(int x, int y, int z) {
		super(x, y);
		System.out.println("Parameterized constructor of B");
		System.out.println("z = " + z);
	}
}
