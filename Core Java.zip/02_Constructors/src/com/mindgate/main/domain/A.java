package com.mindgate.main.domain;

public class A {
	public A() {
		System.out.println("Default constructor of A");
	}

	public A(int x, int y) {
		System.out.println("Parameterized constructor of A");
		System.out.println("x = " + x);
		System.out.println("y = " + y);
	}

}
