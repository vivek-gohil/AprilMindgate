package com.mindgate.main;

import com.mindgate.main.domain.Employee;
import com.mindgate.main.util.PrintUtil;

public class ArraysMainV2 {
	public static void main(String[] args) {
		String[] friends = { "Poornima", "Jothi", "Sai Eswari", "Shiva Prasad", "rishabh" };

		PrintUtil printUtil = new PrintUtil();

		printUtil.doPrinting(friends);

		Employee gokul = new Employee(101, "Gokul", 10000);
		Employee hariharan = new Employee(102, "Hariharan", 10000);
		Employee anand = new Employee(103, "Anand", 10000);
		Employee poornaChandra = new Employee(104, "Poorna Chandra", 10000);

		Employee employees[] = new Employee[4];
		employees[0] = gokul;
		employees[1] = hariharan;
		employees[2] = anand;
		employees[3] = poornaChandra;

		printUtil.doPrinting(employees);
	}
}
