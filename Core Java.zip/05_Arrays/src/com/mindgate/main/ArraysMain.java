package com.mindgate.main;

import java.util.Scanner;

public class ArraysMain {
	public static void main(String[] args) {
		int[] numbers = new int[5];
		Scanner scanner = new Scanner(System.in);

		System.out.println("Storing numbers");
//		numbers[0] = 5;
//		numbers[1] = -5;
//		numbers[2] = 0;
//		numbers[3] = 33;
//		numbers[4] = 521;

		System.out.println("Enter 5 numbers ");
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = scanner.nextInt();
		}

		System.out.println();

		System.out.println("Display numbers");

		for (int i : numbers) {
			System.out.println(i);
		}

		// for (int i = 0; i < 5; i++) {
//			System.out.println(numbers[i]);
//		}

//		System.out.println(numbers[0]);
//		System.out.println(numbers[1]);
//		System.out.println(numbers[2]);
//		System.out.println(numbers[3]);
//		System.out.println(numbers[4]);
//		System.out.println(numbers[5]);
	}
}
