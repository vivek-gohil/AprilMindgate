package com.mindgate.main.util;

import com.mindgate.main.domain.Employee;

public class PrintUtil {

	public void doPrinting(String[] text) {
		for (String s : text) {
			System.out.println(s);
		}
	}

	public void doPrinting(Employee[] employees) {
		for (Employee e : employees) {
			System.out.println();
			System.out.println(e.getEmployeeId());
			System.out.println(e.getName());
			System.out.println(e.getSalary());
			System.out.println();
		}
	}

}
