package com.mindgate.main;

import com.mindgate.main.domain.Demo;

public class StaticMain {
	public static void main(String[] args) {

		System.out.println("main start");
		// Demo d;
		// Demo.display();

		try {
			Class.forName("com.mindgate.main.domain.Demo");
		} catch (ClassNotFoundException e) {
			System.out.println("Invalid class name");

		}

		System.out.println("main end");

//		new Demo();

//		Demo demo = new Demo();
//		demo.display();
//		//10 10 20 20
//		System.out.println("------------------");
//		Demo demo2 = new Demo();
//		// 10 20 20 30 
//		demo2.display();

	}
}
