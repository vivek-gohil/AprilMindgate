package com.mindgate.main.domain;

public class Demo {
	private static int number1 = 10;
	private static int number2 = 10;

	static {
		System.out.println("in static block");
	}

	{
		System.out.println("in non static block");
	}

	public Demo() {
		System.out.println("in constructor of Demo");
	}

	public static void display() {
		System.out.println("number 1 = " + number1); // 10
		System.out.println("number 2 = " + number2); // 10
		number1 = number1 + 10;
		number2 = number2 + 10;
		System.out.println("number 1 = " + number1); // 20
		System.out.println("number 2 = " + number2); // 20 , 10
	}
}
