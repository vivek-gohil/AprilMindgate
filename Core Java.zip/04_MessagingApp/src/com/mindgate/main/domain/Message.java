package com.mindgate.main.domain;

public class Message {
	public void sendMessage(String to, String messageText) {
		System.out.println("Sending Message to = " + to);
		System.out.println("Message = " + messageText);
	}
}
