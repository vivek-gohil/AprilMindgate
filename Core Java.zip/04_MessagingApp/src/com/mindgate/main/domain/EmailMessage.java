package com.mindgate.main.domain;

public class EmailMessage extends Message {
	@Override
	public void sendMessage(String to, String messageText) {
		System.out.println("Sending Email Message to = " + to);
		System.out.println("Message = " + messageText);
	}
}
