package com.mindgate.main.domain;

public class InstagramMessage extends Message {
	@Override
	public void sendMessage(String to, String messageText) {
		System.out.println("Sending Instagram Message to = " + to);
		System.out.println("Message = " + messageText);
	}
}
