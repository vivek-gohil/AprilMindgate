package com.mindgate.main.domain;

public class WhatsAppMessage extends Message {
	@Override
	public void sendMessage(String to, String messageText) {
		System.out.println("Sending WhatsApp to = " + to);
		System.out.println("Message = " + messageText);
	}
}
