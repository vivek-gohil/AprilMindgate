package com.mindgate.main.factory;

import com.mindgate.main.domain.EmailMessage;
import com.mindgate.main.domain.InstagramMessage;
import com.mindgate.main.domain.Message;
import com.mindgate.main.domain.SMSMessage;
import com.mindgate.main.domain.WhatsAppMessage;

public class MessageFactory {
	public Message getMessageObject(int choice) {
		if (choice == 1)
			return new SMSMessage();
		if (choice == 2)
			return new EmailMessage();
		if (choice == 3)
			return new WhatsAppMessage();
		if (choice == 4)
			return new InstagramMessage();
		else
			return null;
	}
}
