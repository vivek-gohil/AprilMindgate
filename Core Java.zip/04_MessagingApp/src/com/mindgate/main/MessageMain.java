package com.mindgate.main;

import java.util.Scanner;

import com.mindgate.main.application.MessageApplication;
import com.mindgate.main.domain.Message;
import com.mindgate.main.factory.MessageFactory;

public class MessageMain {
	public static void main(String[] args) {
		MessageFactory factory = new MessageFactory();

		Scanner scanner = new Scanner(System.in);
		Message message = null;
		int choice;
		String to = null, messageText = null;

		System.out.println("1. SMS Message");
		System.out.println("2. Email Message");
		System.out.println("3. WhatsApp Message");
		System.out.println("4. Instagram Message");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();

		message = factory.getMessageObject(choice);

		MessageApplication application = new MessageApplication(message);

		switch (choice) {
		case 1:
			System.out.println("Enter mobile number to send SMS Message");
			to = scanner.next();
			scanner.nextLine();
			System.out.println("Enter SMS message text");
			messageText = scanner.nextLine();
			break;
		case 2:
			System.out.println("Enter Email id to send Email Message");
			to = scanner.next();
			scanner.nextLine();
			System.out.println("Enter Email message text");
			messageText = scanner.nextLine();
			break;
		case 3:
			System.out.println("Enter mobile number to send WhatsApp Message");
			to = scanner.next();
			scanner.nextLine();
			System.out.println("Enter WhatsApp message text");
			messageText = scanner.nextLine();
			break;
		case 4:
			System.out.println("Enter Instagram Id to send Instagram Message");
			to = scanner.next();
			scanner.nextLine();
			System.out.println("Enter Instagram message text");
			messageText = scanner.nextLine();
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}

		application.processMessage(to, messageText);

	}
}
