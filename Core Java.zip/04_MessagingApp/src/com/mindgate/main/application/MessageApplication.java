package com.mindgate.main.application;

import com.mindgate.main.domain.Message;

public class MessageApplication {

	private Message message;

	public MessageApplication() {

	}

	public MessageApplication(Message message) {
		this.message = message;
	}

	public void processMessage(String to, String messageText) {
		message.sendMessage(to, messageText);
	}

}
