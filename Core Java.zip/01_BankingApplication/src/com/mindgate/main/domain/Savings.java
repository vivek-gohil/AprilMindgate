package com.mindgate.main.domain;

public class Savings extends Account {
	private boolean isSalary;
	private double minimumBalance;

	public Savings() {
		System.out.println("Default constructor of Savings");
	}

	public Savings(int accountNumber, String name, double balance, boolean isSalary, double minimumBalance) {
		super(accountNumber, name, balance);
		this.isSalary = isSalary;
		this.minimumBalance = minimumBalance;
		System.out.println("Parameterized constructor of Savings");
	}

	public boolean isSalary() {
		return isSalary;
	}

	public void setSalary(boolean isSalary) {
		this.isSalary = isSalary;
	}

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	@Override
	public boolean withdraw(double amount) {
		if (isSalary) {
			if (amount > 0 && amount <= getBalance()) {
				setBalance(getBalance() - amount);
				return true;
			}
		} else {
			if (amount > 0 && getBalance() - amount >= minimumBalance) {
				setBalance(getBalance() - amount);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deposit(double amount) {
		if (amount > 0) {
			setBalance(getBalance() + amount);
			return true;
		} else
			return false;

	}

}
