package com.mindgate.main;

import com.mindgate.main.domain.Savings;

public class AccountMainV3 {

	public static void main(String[] args) {
		Savings savings = new Savings(101, "Mindgate", 1000, false, 500);
		boolean result = savings.withdraw(100);
		System.out.println(result);
		System.out.println("---------------------");
		result = savings.deposit(300);
		System.out.println(result);
	}

}
