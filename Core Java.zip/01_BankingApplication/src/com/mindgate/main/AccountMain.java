package com.mindgate.main;

import com.mindgate.main.domain.Account;

public class AccountMain {

	public static void main(String[] args) {
		System.out.println("main start");

		Account account = new Account();

		// Setting value to account object
		account.setAccountNumber(101);
		account.setName("Mindgate");
		account.setBalance(1000);

		// Print value of account variables
		System.out.println(account.getAccountNumber());
		System.out.println(account.getName());
		System.out.println(account.getBalance());

		System.out.println("---------------------");

		System.out.println("withdraw = 300");
		boolean result = account.withdraw(300);
		if (result) {
			System.out.println("Withdraw successfull");
			System.out.println("Balance = " + account.getBalance());
		} else {
			System.out.println("Withdraw failed!");
			System.out.println("Balance = " + account.getBalance());
		}

		System.out.println("---------------------");
		System.out.println("deposit = 500");
		result = account.deposit(500);
		if (result) {
			System.out.println("Deposit successfull");
			System.out.println("Balance = " + account.getBalance());
		} else {
			System.out.println("Deposit Failed");
			System.out.println("Balance = " + account.getBalance());
		}

		System.out.println("main end");
	}

}
