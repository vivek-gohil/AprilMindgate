package com.mindgate.main;

import com.mindgate.main.domain.Current;

public class AccountMainV4 {

	public static void main(String[] args) {
		
		Current current = new Current(101, "Mindgate", 5000, 50000);

		System.out.println("withdraw=2000");
		boolean result = current.withdraw(2000);
		System.out.println(result);
		System.out.println("Balance = " + current.getBalance());
		System.out.println("OverdraftBalance = " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("withdraw=10000");
		result = current.withdraw(10000);
		System.out.println(result);
		System.out.println("Balance = " + current.getBalance());
		System.out.println("OverdraftBalance = " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("withdraw=5000");
		result = current.withdraw(5000);
		System.out.println(result);
		System.out.println("Balance = " + current.getBalance());
		System.out.println("OverdraftBalance = " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("deposit=5000");
		result = current.deposit(5000);
		System.out.println(result);
		System.out.println("Balance = " + current.getBalance());
		System.out.println("OverdraftBalance = " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("deposit=10000");
		result = current.deposit(10000);
		System.out.println(result);
		System.out.println("Balance = " + current.getBalance());
		System.out.println("OverdraftBalance = " + current.getOverdraftBalance());

		System.out.println();

		System.out.println("deposit=3000");
		result = current.deposit(3000);
		System.out.println(result);
		System.out.println("Balance = " + current.getBalance());
		System.out.println("OverdraftBalance = " + current.getOverdraftBalance());

	}

}
