package com.mindgate.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class CollectionsMain {
	public static void main(String[] args) {
		System.out.println("1. ArrayList");
		List<String> nameList = new ArrayList<String>();
		nameList.add("Gokul");
		nameList.add("Poornima");
		nameList.add("Sai Eswari");
		nameList.add("Poornima");
		nameList.add("Sai Eswari");
		nameList.add("Poornima");
		nameList.add("Gokul");

		System.out.println(nameList);
		System.out.println(nameList.size());
		System.out.println(nameList.get(2));
		nameList.remove(3);
		System.out.println(nameList);

		System.out.println();

		System.out.println("2. HashSet");
		Set<String> nameSet = new HashSet<String>();

		nameSet.add("Anand");
		nameSet.add("Hariharan");
		nameSet.add("Poorna Chandra");

		System.out.println(nameSet);

		System.out.println();

		System.out.println("3. TreeSet");
		SortedSet<String> nameSortedSet = new TreeSet<String>();
		nameSortedSet.add("Rishabh");
		nameSortedSet.add("Shiva Prasad");
		nameSortedSet.add("Santhosh");

		System.out.println(nameSortedSet);

		System.out.println("");
		System.out.println("4. HashMap");
		Map<Integer, String> nameHashMap = new HashMap<Integer, String>();
		nameHashMap.put(1, "Santhosh");
		nameHashMap.put(191, "Gokul");
		nameHashMap.put(10645, "Hariharan");
		nameHashMap.put(48, "Poorna Chandra");
		nameHashMap.put(10645, "Vivek");

		System.out.println(nameHashMap);

		System.out.println("5. TreeMap");
		nameHashMap = new TreeMap<Integer, String>();
		nameHashMap.put(1, "Santhosh");
		nameHashMap.put(191, "Gokul");
		nameHashMap.put(10645, "Hariharan");
		nameHashMap.put(48, "Poorna Chandra");
		nameHashMap.put(10645, "Vivek");

		System.out.println(nameHashMap);

	}
}
