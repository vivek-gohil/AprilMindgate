package com.mindgate.main;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.mindgate.main.domain.Employee;
import com.mindgate.main.sorts.CompareEmployeeByEmployeeId;

public class EmployeeCollectionsMain {
	public static void main(String[] args) {
		Employee employee1 = new Employee(101, "Gokul", 1000);
		Employee employee2 = new Employee(102, "Hariharan", 1000);
		Employee employee3 = new Employee(103, "Ananad", 1000);

		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);
		employeeList.add(employee1);
		employeeList.add(employee2);

		for (Employee e : employeeList) {
			System.out.println(e);
		}

		System.out.println("--------------------------------------");

		Set<Employee> employeeSet = new HashSet<Employee>();
		Employee employee4 = new Employee(101, "Gokul", 1000);
		Employee employee5 = new Employee(102, "Hariharan", 1000);

		employeeSet.add(employee1); // hashcode
		employeeSet.add(employee2); // hashcode
		employeeSet.add(employee3); // hashcode
		employeeSet.add(employee4); // hashcode and equals
		employeeSet.add(employee5); // hashcode and equals

		for (Employee e : employeeSet) {
			System.out.println(e);
			System.out.println(e.hashCode());
			System.out.println();
		}

		System.out.println("--------------------------------------");
		System.out.println("SortedSet");
		CompareEmployeeByEmployeeId byEmployeeId = new CompareEmployeeByEmployeeId();
		SortedSet<Employee> employeeSortedSet = new TreeSet<Employee>(byEmployeeId);
		employeeSortedSet.add(employee1);
		employeeSortedSet.add(employee2);
		employeeSortedSet.add(employee3);
		employeeSortedSet.add(employee1);
		employeeSortedSet.add(employee2);

		for (Employee e : employeeSortedSet) {
			System.out.println(e);
		}

	}
}
