package com.mindgate.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.mindgate.main.domain.Employee;
import com.mindgate.main.sorts.CompareEmployeeByEmployeeId;

public class EmployeeSortingMain {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int choice;

		Employee employee1 = new Employee(101, "Gokul", 1000);
		Employee employee2 = new Employee(102, "Hariharan", 1000);
		Employee employee3 = new Employee(103, "Ananad", 1000);

		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);

		for (Employee employee : employeeList) {
			System.out.println(employee);
		}
		System.out.println();
		System.out.println("1. Sort Employee By EmployeeId");
		System.out.println("2. Sort Employee By Name");
		System.out.println("3. Sort Employee By Salary");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();

		switch (choice) {
		case 1:
			CompareEmployeeByEmployeeId compareEmployeeByEmployeeId = new CompareEmployeeByEmployeeId();
			Collections.sort(employeeList, compareEmployeeByEmployeeId);
			break;
		case 2:
			break;
		case 3:
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}
		
		for (Employee employee : employeeList) {
			System.out.println(employee);
		}
		

	}
}







