package com.mindgate.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.mindgate.main.domain.Employee;

public class IteratorMain {
	public static void main(String[] args) {
		Employee employee1 = new Employee(101, "Gokul", 1000);
		Employee employee2 = new Employee(102, "Hariharan", 1000);
		Employee employee3 = new Employee(103, "Ananad", 1000);

		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);

		Iterator<Employee> employeeIterator = employeeList.iterator();

		while (employeeIterator.hasNext()) {
			Employee employee = (Employee) employeeIterator.next();
			System.out.println(employee);
		}

	}
}
