package com.mindgate.main.sorts;

import java.util.Comparator;

import com.mindgate.main.domain.Employee;

public class CompareEmployeeByEmployeeId implements Comparator<Employee> {

	@Override
	public int compare(Employee employee1, Employee employee2) {

		return employee1.getEmployeeId() - employee2.getEmployeeId();
	}

}
