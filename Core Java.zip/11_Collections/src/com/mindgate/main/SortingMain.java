package com.mindgate.main;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.mindgate.main.domain.Employee;

public class SortingMain {
	public static void main(String[] args) {
		int[] numbers = { 10, 20, 11, 5, 2, 6 };

		System.out.println(numbers);
		System.out.println(Arrays.toString(numbers));
		Arrays.sort(numbers);
		System.out.println(Arrays.toString(numbers));

		System.out.println();

		String[] names = { "Hari", "Shiva", "Gokul" };
		System.out.println(Arrays.toString(names));
		Arrays.sort(names);
		System.out.println(Arrays.toString(names));

		System.out.println();

		Employee employee1 = new Employee(101, "Gokul", 1000);
		Employee employee2 = new Employee(102, "Hariharan", 1000);
		Employee employee3 = new Employee(103, "Ananad", 1000);

		Employee[] employees = { employee1, employee2, employee3 };

//		System.out.println(Arrays.toString(employees));
//		Arrays.sort(employees);
//		System.out.println(Arrays.toString(employees));

		System.out.println();

		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);

		System.out.println(employeeList);
		Collections.sort(employeeList);
		System.out.println(employeeList);
	}
}











