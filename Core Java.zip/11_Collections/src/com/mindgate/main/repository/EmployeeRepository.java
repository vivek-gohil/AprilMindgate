package com.mindgate.main.repository;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

import com.mindgate.main.domain.Employee;

public class EmployeeRepository implements EmployeeRepositoryInterface {

	private Set<Employee> employeeSet = new HashSet<Employee>();

	@Override
	public boolean addNewEmployee(Employee employee) {

		return false;
	}

	@Override
	public Employee getEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void sortEmployeeByName(Set<Employee> employeeSet, Comparator<Employee> compareEmployeeByName) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sortEmployeeBySalary(Set<Employee> employeeSet, Comparator<Employee> compareEmployeeBySalary) {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

}
