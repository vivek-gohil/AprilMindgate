package com.mindgate.main.repository;

import java.util.Comparator;
import java.util.Set;

import com.mindgate.main.domain.Employee;

public interface EmployeeRepositoryInterface {
	public boolean addNewEmployee(Employee employee);

	public Employee updateEmployee(Employee employee);

	public Employee getEmployeeByEmployeeId(int employeeId);

	public Set<Employee> getAllEmployees();

	public boolean deleteEmployeeByEmployeeId(int employeeId);

	public void sortEmployeeByName(Set<Employee> employeeSet, Comparator<Employee> compareEmployeeByName);

	public void sortEmployeeBySalary(Set<Employee> employeeSet, Comparator<Employee> compareEmployeeBySalary);

}












