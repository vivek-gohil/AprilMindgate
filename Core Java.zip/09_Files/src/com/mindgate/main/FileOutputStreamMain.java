package com.mindgate.main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileOutputStreamMain {
	public static void main(String[] args) {
		File file = null;
		FileOutputStream fileOutputStream = null;
		String path;
		String data;
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter file path");
		path = scanner.nextLine();

		file = new File(path);

		// scanner.nextLine();
		System.out.println("Enter data for file");
		data = scanner.nextLine();

		try {
			fileOutputStream = new FileOutputStream(file, true);
			fileOutputStream.write(data.getBytes());
			System.out.println("Please check your file : " + file.getAbsolutePath());
		} catch (IOException e) {
			System.out.println("IO Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				fileOutputStream.close();
			} catch (IOException e) {
				System.out.println("failed to close FileWriter");
				System.out.println(e.getMessage());
			}
			scanner.close();
		}
	}
}
