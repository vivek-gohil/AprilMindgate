package com.mindgate.main;

import java.io.File;

public class FileMetadataTest {

	public static void main(String[] args) {
		File file = new File("D:\\Vivek Gohil\\Training\\Core Java\\Mindgate 24\\test.txt");

		if (file.exists()) {
			System.out.println("File name = " + file.getName());
			System.out.println("Location " + file.getAbsolutePath());
			System.out.println("Size = " + file.length() + " bytes");
		} else {
			System.out.println("File not found!");
		}
	}

}
