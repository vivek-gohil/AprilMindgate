package com.mindgate.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class BufferedReaaderMain {
	public static void main(String[] args) {
		File file = null;
		BufferedReader bufferedReader = null;
		Scanner scanner = new Scanner(System.in);
		String data = "";
		String path;

		System.out.println("Enter file location/path ");
		path = scanner.nextLine();

		file = new File(path);

		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			String start = bufferedReader.readLine();
			while (start != null) {
				data = data + start + "\n";
				start = bufferedReader.readLine();
			}
			System.out.println(data);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				bufferedReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			scanner.close();
		}
	}
}
