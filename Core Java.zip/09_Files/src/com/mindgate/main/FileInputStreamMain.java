package com.mindgate.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileInputStreamMain {
	public static void main(String[] args) {
		File file = null;
		FileInputStream fileInputStream = null;
		Scanner scanner = new Scanner(System.in);
		byte[] data = null;
		String path;

		System.out.println("Enter file location/path ");
		path = scanner.nextLine();

		file = new File(path);
		data = new byte[(int) file.length()];
		try {
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(data);
			for (byte b : data) {
				System.out.print((char) b);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Invalid file path!");
			System.out.println(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fileInputStream.close();
			} catch (IOException e) {
				System.out.println("Failed to close FileReader");
			}
			scanner.close();
		}
	}
}
