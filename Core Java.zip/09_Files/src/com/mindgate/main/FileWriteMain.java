package com.mindgate.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWriteMain {
	public static void main(String[] args) {
		File file = null;
		FileWriter fileWriter = null;
		String path;
		String data;
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter file path");
		path = scanner.nextLine();

		file = new File(path);

		// scanner.nextLine();
		System.out.println("Enter data for file");
		data = scanner.nextLine();

		try {
			fileWriter = new FileWriter(file,true);
			fileWriter.write(data);
			System.out.println("Please check your file : " + file.getAbsolutePath());
		} catch (IOException e) {
			System.out.println("IO Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("failed to close FileWriter");
				System.out.println(e.getMessage());
			}
			scanner.close();
		}
	}
}
